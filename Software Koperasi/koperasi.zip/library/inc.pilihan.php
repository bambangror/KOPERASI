<?php
# Membuat daftar bulan
$listBulan = array("00" => "....", "01" => "Januari", "02" => "Februari", "03" => "Maret",
				 "04" => "April", "05" => "Mei", "06" => "Juni", "07" => "Juli",
				 "08" => "Agustus", "09" => "September", "10" => "Oktober",
				 "11" => "November", "12" => "Desember");

# Membuat daftar Nama Bulan
$listBulan2 = array("00" => "....", "01" => "01. Januari", "02" => "02. Februari", "03" => "03. Maret",
				 "04" => "04. April", "05" => "05. Mei", "06" => "06. Juni", "07" => "07. Juli",
				 "08" => "08. Agustus", "09" => "09. September", "10" => "10. Oktober",
				 "11" => "11. November", "12" => "12. Desember");

# Membuat daftar Pilihan Pekerjaan
$pekerjaan	= array("TNI", "Polri", "Guru", "PNS", "Karyawan", "Petani", "Nelayan");

?>