<ul>
	<li><a href="?open=Laporan-Bagian" target="_blank">Laporan Data Bagian 
	</a>
	<li><a href="?open=Laporan-Jenis-Simpanan" target="_blank">Laporan Data Jenis Simpanan 
	</a>
	<li><a href="?open=Laporan-Jenis-Pinjaman" target="_blank">Laporan Data Jenis Pinjaman
	</a>
	<li><a href="?open=Laporan-Pegawai" target="_blank">Laporan Data Pegawai
	</a>
	<li><a href="?open=Laporan-Nasabah" target="_blank">Laporan Data Nasabah
	</a>
	<li><a href="?open=Laporan-Pinjaman-Nasabah" target="_blank">Laporan Pinjaman per Nasabah</a>
    <li><a href="?open=Laporan-Pinjaman-Periode" target="_blank">Laporan Pinjaman per Periode</a>
    <li><a href="?open=Laporan-Pinjaman-Bulan" target="_blank">Laporan Pinjaman per Bulan</a>
    <li><a href="?open=Laporan-Simpanan-Nasabah" target="_blank">Laporan Simpanan per Nasabah</a>
    <li><a href="?open=Laporan-Simpanan-Periode" target="_blank">Laporan Simpanan per Periode</a>     
    <li><a href="?open=Laporan-Simpanan-Bulan" target="_blank">Laporan Simpanan per Bulan</a>
    <li>Laporan Simpanan Transaksi per Nasabah
</ul>
